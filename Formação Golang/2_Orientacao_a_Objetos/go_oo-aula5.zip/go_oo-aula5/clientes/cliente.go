package clientes

type Titular struct {
	Nome, CPF, Profissao string
}
