# Go OO - Aula 5 - "Interface e novo tipo de conta"
> Código da Alura cursos online

![](/go_alura_logo.png)



